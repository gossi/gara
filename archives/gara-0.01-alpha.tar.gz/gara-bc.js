if(!Array.prototype.contains){
Array.prototype.contains=function(_1){
return base2.Array2.contains(this,_1);
};
}
if(!Array.prototype.forEach){
Array.prototype.forEach=function(_2,_3){
return base2.Array2.forEach(this,_2,_3);
};
}
if(!Array.prototype.indexOf){
Array.prototype.indexOf=function(_4,_5){
return base2.Array2.indexOf(this,_4,_5);
};
}
if(!Array.prototype.insertAt){
Array.prototype.insertAt=function(_6,_7){
return base2.Array2.insertAt(this,_6,_7);
};
}
if(!Array.prototype.insertBefore){
Array.prototype.insertBefore=function(_8,_9){
return base2.Array2.insertBefore(this,_8,_9);
};
}
if(!Array.prototype.lastIndexOf){
Array.prototype.lastIndexOf=function(_a,_b){
return base2.Array2.lastIndexOf(this,_a,_b);
};
}
if(!Array.prototype.remove){
Array.prototype.remove=function(_c){
return base2.Array2.remove(this,_c);
};
}
if(!Array.prototype.removeAt){
Array.prototype.removeAt=function(_d){
return base2.Array2.removeAt(this,_d);
};
}
var gara={};
new function(){
$class("Namespace",{imports:"",exports:"",namespace:"",name:"",$constructor:function(_e){
this.name=_e.name||"gara";
this.imports=_e.imports||"";
this.exports=_e.exports||"";
if(this.name!="gara"){
this.name="gara."+this.name;
}
var _f=("gara,"+this.imports).split(",");
this.imports="";
_f.forEach(function(v,k,arr){
if(gara[v]){
this.imports+=gara[v].namespace;
}
},this);
var _13=this.exports.split(",");
this.exports="";
_13.forEach(function(v,k,arr){
this.exports+=this.name+"."+v+"="+v+";";
this.namespace+="var "+v+"="+this.name+"."+v+";";
},this);
}});
var _17=new Namespace({exports:"Namespace,EventManager,OutOfBoundsException",name:"gara"});
$class("EventManager",{_instance:null,$constructor:function(){
this._listeners=[];
base2.DOM.bind(document);
var _18=this;
window.onunload=function(e){
_18.handleEvent(e);
};
},getInstance:$static(function(){
if(this._instance==null){
this._instance=new gara.EventManager();
}
return this._instance;
}),addListener:function(_1a,_1b,_1c){
_1a.addEventListener(_1b,_1c,false);
var _1d={domNode:_1a,type:_1b,listener:_1c};
this._listeners.push(_1d);
return _1d;
},handleEvent:function(e){
this._unregisterAllEvents();
},removeListener:function(e){
e.domNode.removeEventListener(e.type,e.listener,false);
if(this._listeners.contains(e)){
this._listeners.remove(e);
}
},_unregisterAllEvents:function(){
while(this._listeners.length>0){
var _20=this._listeners.pop();
this.removeListener(_20);
}
},toString:function(){
return "[gara.EventManager]";
}});
$class("OutOfBoundsException",{$extends:Exception,$constructor:function(_21){
this.message=String(_21);
this.name=$class.typeOf(this);
}});
var _22=gara.onDOMLoaded=function(f){
if(document.addEventListener){
document.addEventListener("DOMContentLoaded",f,false);
}else{
if(window.ActiveX){
document.write("<scr"+"ipt id=__ie_onload defer src=javascript:void(0)></script>");
var _24=document.getElementById("__ie_onload");
_24.onreadystatechange=function(){
if(this.readyState=="complete"){
f();
}
};
}else{
if(/WebKit/i.test(navigator.userAgent)){
var _25=setInterval(function(){
if(/loaded|complete/.test(document.readyState)){
f();
}
},10);
}else{
window.onload=f;
}
}
}
};
eval(_17.exports);
gara.namespace=_17.namespace;
gara.toString=function(){
return "[gara]";
};
};
delete Namespace;
delete EventManager;
delete OutOfBoundsException;
gara.jswt={};
new function(){
var _26=new gara.Namespace({name:"jswt",exports:"ControlManager,Widget,Control,Item,List,ListItem,Tree,TreeItem,TabFolder,TabItem,FocusListener,SelectionListener",imports:"gara"});
eval(_26.imports);
gara.jswt.BOTTOM=1<<10;
gara.jswt.TOP=1<<7;
$interface("FocusListener",{focusGained:function(){
},focusLost:function(){
},toString:function(){
return "[gara.jswt.FocusListener]";
}});
$interface("SelectionListener",{widgetSelected:function(_27){
},toString:function(){
return "[gara.jswt.SelectionListener]";
}});
function strReplace(_28,_29,_2a){
output=""+_28;
while(output.indexOf(_29)>-1){
pos=output.indexOf(_29);
output=""+(output.substring(0,pos)+_2a+output.substring((pos+_29.length),output.length));
}
return output;
}
$class("Widget",{domref:null,$constructor:function(){
this._className="";
this._baseClass="";
this._listener={};
},addClassName:function(_2b){
this._className+=" "+_2b;
this._changed=true;
},addListener:function(_2c,_2d){
if(!this._listener.hasOwnProperty(_2c)){
this._listener[_2c]=new Array();
}
this._listener[_2c].push(_2d);
this.registerListener(_2c,_2d);
},getClassName:function(){
return this._className;
},registerListener:$abstract(function(_2e,_2f){
}),removeClassName:function(_30){
this._className=strReplace(this._className,_30,"");
this._changed=true;
},removeListener:function(_31,_32){
this._listener[_31].remove(_32);
},setClassName:function(_33){
this._className=_33;
this._changed=true;
},toString:function(){
return "[gara.jswt.Widget]";
}});
$class("Control",{$extends:Widget,$constructor:function(){
this.$base();
this._focusListener=[];
this._hasFocus=false;
gara.jswt.ControlManager.getInstance().addControl(this);
this.addFocusListener(gara.jswt.ControlManager.getInstance());
},addFocusListener:function(_34){
if(!$class.implementationOf(_34,gara.jswt.FocusListener)){
throw new TypeError("listener is not a gara.jswt.FocusListener");
}
this._focusListener.push(_34);
},forceFocus:function(){
this._hasFocus=true;
this.removeClassName(this._baseClass+"Inactive");
this.addClassName(this._baseClass+"Active");
this.update();
for(var i=0,len=this._focusListener.length;i<len;++i){
this._focusListener[i].focusGained(this);
}
},handleEvent:$abstract(function(e){
}),isFocusControl:function(){
return this._hasFocus;
},looseFocus:function(){
this._hasFocus=false;
this.removeClassName(this._baseClass+"Active");
this.addClassName(this._baseClass+"Inactive");
this.update();
for(var i=0,len=this._focusListener.length;i<len;++i){
this._focusListener[i].focusLost(this);
}
},removeFocusListener:function(_3a){
if(!_3a.$class.implementsInterface(gara.jswt.FocusListener)){
throw new TypeError("listener is not a gara.jswt.FocusListener");
}
if(this._focusListener.contains(_3a)){
this._focusListener.remove(_3a);
}
},toString:function(){
return "[gara.jswt.Control";
},update:$abstract(function(){
})});
$class("Item",{$extends:Widget,$constructor:function(){
this.$base();
this._changed=false;
this._image=null;
this._text="";
},getImage:function(){
return this._image;
},getText:function(){
return this._text;
},hasChanged:function(){
return this._changed;
},isCreated:function(){
return this.domref!=null;
},releaseChange:function(){
this._changed=false;
},setActive:function(_3b){
this._active=_3b;
if(_3b){
this.addClassName("active");
}else{
this.removeClassName("active");
}
this._changed=true;
},setImage:function(_3c){
if(!$class.instanceOf(_3c,Image)){
throw new TypeError("image not instance of Image");
}
this._image=_3c;
this._changed=true;
},setSelected:function(){
this.addClassName("selected");
},setText:function(_3d){
this._text=_3d;
this._changed=true;
},setUnselected:function(){
this.removeClassName("selected");
},toString:function(){
return "[gara.jswt.Item]";
}});
$class("List",{$extends:Control,$constructor:function(_3e){
this.$base();
this._items=[];
this._selection=[];
this._selectionListener=[];
this._activeItem=null;
this._shiftItem=null;
this._parentNode=_3e;
this._className=this._baseClass="jsWTList";
},_activateItem:function(_3f){
if(!$class.instanceOf(_3f,gara.jswt.ListItem)){
throw new TypeError("item is not type of gara.jswt.ListItem");
}
if(this._activeItem!=null){
this._activeItem.setActive(false);
}
this._activeItem=_3f;
this._activeItem.setActive(true);
this.update();
},addItem:function(_40){
if(!$class.instanceOf(_40,gara.jswt.ListItem)){
throw new TypeError("item is not type of gara.jswt.ListItem");
}
this._items.push(_40);
},addSelectionListener:function(_41){
if(!$class.instanceOf(_41,gara.jswt.SelectionListener)){
throw new TypeError("listener is not instance of gara.jswt.SelectionListener");
}
this._selectionListener.push(_41);
},deselect:function(_42){
if(!$class.instanceOf(_42,gara.jswt.ListItem)){
throw new TypeError("item not instance of gara.jswt.ListItem");
}
if(this._selection.contains(_42)){
this._selection.remove(_42);
this.notifySelectionListener();
_42.setUnselected();
this._shiftItem=_42;
this._activateItem(_42);
}
},deselectAll:function(){
for(var i=0,len=this._items.length;i<len;++i){
this.deselect(this._items[i]);
}
this.update();
},getItem:function(_45){
if(_45>=this._items.length){
throw new gara.OutOfBoundsException("Your item lives outside of this list");
}
return this._items[_45];
},getItemCount:function(){
return this._items.length;
},getItems:function(){
return this._items;
},getSelection:function(){
return this._selection;
},getSelectionCount:function(){
return this._selection.length;
},handleEvent:function(e){
var obj=e.target.obj||null;
switch(e.type){
case "mousedown":
if(!this._hasFocus){
this.forceFocus();
}
if($class.instanceOf(obj,gara.jswt.ListItem)){
var _48=obj;
if(!e.ctrlKey&&!e.shiftKey){
this.select(_48,false);
}else{
if(e.ctrlKey&&e.shiftKey){
this.selectRange(_48,true);
}else{
if(e.shiftKey){
this.selectRange(_48,false);
}else{
if(e.ctrlKey){
if(this._selection.contains(_48)){
this.deselect(_48);
}else{
this.select(_48,true);
}
}else{
this.select(_48);
}
}
}
}
}
break;
}
e.stopPropagation();
},_handleKeyEvent:function(e){
if(this._activeItem==null){
return;
}
switch(e.keyCode){
case 38:
var _4a=false;
var _4b=this.indexOf(this._activeItem);
if(_4b!=0){
_4a=this._items[_4b-1];
}
if(_4a){
if(!e.ctrlKey&&!e.shiftKey){
this.select(_4a,false);
}else{
if(e.ctrlKey&&e.shiftKey){
this.selectRange(_4a,true);
}else{
if(e.shiftKey){
this.selectRange(_4a,false);
}else{
if(e.ctrlKey){
this._activateItem(_4a);
}
}
}
}
}
break;
case 40:
var _4c=false;
var _4b=this.indexOf(this._activeItem);
if(_4b!=this._items.length-1){
_4c=this._items[_4b+1];
}
if(_4c){
if(!e.ctrlKey&&!e.shiftKey){
this.select(_4c,false);
}else{
if(e.ctrlKey&&e.shiftKey){
this.selectRange(_4c,true);
}else{
if(e.shiftKey){
this.selectRange(_4c,false);
}else{
if(e.ctrlKey){
this._activateItem(_4c);
}
}
}
}
}
break;
case 32:
if(this._selection.contains(this._activeItem)&&e.ctrlKey){
this.deselect(this._activeItem);
}else{
this.select(this._activeItem,true);
}
break;
case 36:
if(!e.ctrlKey&&!e.shiftKey){
this.select(this._items[0],false);
}else{
if(e.shiftKey){
this.selectRange(this._items[0],false);
}else{
if(e.ctrlKey){
this._activateItem(this._items[0]);
}
}
}
break;
case 35:
var _4d=this._items.length-1;
if(!e.ctrlKey&&!e.shiftKey){
this.select(this._items[_4d],false);
}else{
if(e.shiftKey){
this.selectRange(this._items[_4d],false);
}else{
if(e.ctrlKey){
this._activateItem(this._items[_4d]);
}
}
}
break;
}
},indexOf:function(_4e){
if(!$class.instanceOf(_4e,gara.jswt.ListItem)){
throw new TypeError("item not instance of gara.jswt.ListItem");
}
if(!this._items.contains(_4e)){
throw new gara.jswt.ItemNotExistsException("item ["+_4e+"] does not exists in this list");
return;
}
return this._items.indexOf(_4e);
},notifySelectionListener:function(){
for(var i=0,len=this._selectionListener.length;i<len;++i){
this._selectionListener[i].widgetSelected(this);
}
},registerListener:function(_51,_52){
if(this.domref!=null){
gara.EventManager.getInstance().addListener(this.domref,_51,_52);
}
},removeSelectionListener:function(_53){
if(!$class.instanceOf(_53,gara.jswt.SelectionListener)){
throw new TypeError("listener is not instance of gara.jswt.SelectionListener");
}
if(this._selectionListener.contains(_53)){
this._selectionListener.remove(_53);
}
},select:function(_54,_55){
if(!$class.instanceOf(_54,gara.jswt.ListItem)){
throw new TypeError("item not instance of gara.jswt.ListItem");
}
if(!_55){
while(this._selection.length){
this._selection.pop().setUnselected();
}
}
if(!this._selection.contains(_54)){
this._selection.push(_54);
_54.setSelected();
this._shiftItem=_54;
this._activateItem(_54);
this.notifySelectionListener();
}
},selectAll:function(){
for(var i=0,len=this._items.length;i<len;++i){
this.select(this._items[i],true);
}
this.update();
},selectRange:function(_58,_59){
if(!$class.instanceOf(_58,gara.jswt.ListItem)){
throw new TypeError("item not instance of gara.jswt.ListItem");
}
if(!_59){
while(this._selection.length){
this._selection.pop().setUnselected();
}
}
var _5a=this.indexOf(this._shiftItem);
var _5b=this.indexOf(_58);
var _5c=_5a>_5b?_5b:_5a;
var to=_5a<_5b?_5b:_5a;
for(var i=_5c;i<=to;++i){
this._selection.push(this._items[i]);
this._items[i].setSelected();
}
this.notifySelectionListener();
this._activateItem(_58);
},toString:function(){
return "[gara.jswt.List]";
},update:function(){
if(this.domref==null){
this.domref=document.createElement("ul");
this.domref.obj=this;
this.domref.control=this;
base2.DOM.bind(this.domref);
var _5f={};
for(var _60 in this._listener){
_5f[_60]=this._listener[_60].concat([]);
}
this.addListener("mousedown",this);
for(var _60 in _5f){
_5f[_60].forEach(function(_61,_62,arr){
this.registerListener(_60,_61);
},this);
}
this._parentNode.appendChild(this.domref);
}
this.domref.className=this._className;
this._items.forEach(function(_64,_65,arr){
if(!_64.isCreated()){
node=_64.create();
this.domref.appendChild(node);
}
if(_64.hasChanged()){
_64.update();
_64.releaseChange();
}
},this);
}});
$class("ListItem",{$extends:Item,$constructor:function(_67){
if(!$class.instanceOf(_67,gara.jswt.List)){
throw new TypeError("list is not type of gara.jswt.List");
}
this.$base();
this._list=_67;
this._list.addItem(this);
this._span=null;
this._spanText=null;
this._img=null;
},create:function(){
this.domref=document.createElement("li");
this.domref.className=this._className;
this.domref.obj=this;
this.domref.control=this._list;
this._img=null;
if(this.image!=null){
this._img=document.createElement("img");
this._img.obj=this;
this._img.control=this._list;
this._img.src=this.image.src;
this._img.alt=this._text;
this.domref.appendChild(this._img);
}
this._spanText=document.createTextNode(this._text);
this._span=document.createElement("span");
this._span.obj=this;
this._span.control=this._list;
this._span.appendChild(this._spanText);
this.domref.appendChild(this._span);
base2.DOM.bind(this.domref);
for(var _68 in this._listener){
this._listener[_68].forEach(function(_69,_6a,arr){
this.registerListener(_68,_69);
},this);
}
this._changed=false;
return this.domref;
},registerListener:function(_6c,_6d){
if(this._img!=null){
gara.EventManager.getInstance().addListener(this._img,_6c,_6d);
}
if(this._span!=null){
gara.EventManager.getInstance().addListener(this._span,_6c,_6d);
}
},toString:function(){
return "[gara.jswt.ListItem]";
},update:function(){
if(this._image!=null&&this._img==null){
this._img=document.createElement("img");
this._img.obj=this;
this._img.control=this._list;
this._img.alt=this._text;
this._img.src=this._image.src;
this.domref.insertBefore(this._img,this._span);
for(var _6e in this._listener){
this._listener[_6e].forEach(function(_6f,_70,arr){
this.registerListener(this._img,_6e,_6f);
},this);
}
}else{
if(this._image!=null){
this._img.src=this._image.src;
this._img.alt=this._text;
}else{
if(this._img!=null&&this._image==null){
this.domref.removeChild(this._img);
this._img=null;
for(var _6e in this._listener){
this._listener[_6e].forEach(function(_72,_73,arr){
gara.EventManager.getInstance().removeListener({domNode:this._img,type:_6e,listener:_72});
},this);
}
}
}
}
this._spanText.nodeValue=this._text;
this.domref.className=this._className;
}});
$class("Tree",{$extends:Control,$constructor:function(_75){
this.$base();
this._showLines=true;
this._shiftItem=null;
this._activeItem=null;
this._parentNode=_75;
this._className=this._baseClass="jsWTTree";
this._selection=[];
this._selectionListeners=[];
this._items=[];
this._firstLevelItems=[];
},_activateItem:function(_76){
if(!$class.instanceOf(_76,gara.jswt.TreeItem)){
throw new TypeError("item is not type of gara.jswt.TreeItem");
}
if(this._activeItem!=null){
this._activeItem.setActive(false);
}
this._activeItem=_76;
this._activeItem.setActive(true);
this.update();
},_addItem:function(_77){
if(!$class.instanceOf(_77,gara.jswt.TreeItem)){
throw new TypeError("item is not type of gara.jswt.TreeItem");
}
var _78=_77.getParentItem();
if(_78==null){
this._items.push(_77);
this._firstLevelItems.push(_77);
}else{
var _79=this._items.indexOf(_78)+getDescendents(_78)+1;
this._items.splice(_79,0,_77);
}
function getDescendents(_7a){
var _7b=0;
if(_7a.getItemCount()>0){
_7a.getItems().forEach(function(_7c,_7d,arr){
if(_7c.getItemCount()>0){
_7b+=getDescendents(_7c);
}
_7b++;
},this);
}
return _7b;
}
},addSelectionListener:function(_7f){
if(!$class.instanceOf(item,gara.jswt.SelectionListener)){
throw new TypeError("listener is not type of gara.jswt.SelectionListener");
}
if(!this._selectionListeners.contains(_7f)){
this._selectionListeners.push(_7f);
}
},deselect:function(_80){
if(!$class.instanceOf(_80,gara.jswt.TreeItem)){
throw new TypeError("item is not type of gara.jswt.TreeItem");
}
if(this._selection.contains(_80)&&_80.getParent()==this){
this._selection.remove(_80);
this._notifySelectionListener();
_80.setChecked(false);
this._shiftItem=_80;
this._activateItem(_80);
}
},deselectAll:function(){
for(var i=this._selection.length;i>=0;--i){
this.deselect(this._selection[i]);
}
this.update();
},getItem:function(_82){
if(_82>=this._items.length){
throw new gara.OutOfBoundsException("Your item lives outside of this Tree");
}
return this._items[_82];
},getItemCount:function(){
return this._items.length;
},getItems:function(){
return this._items;
},getLinesVisible:function(){
return this._showLines;
},getSelection:function(){
return this._selection;
},getSelectionCount:function(){
return this._selection.length;
},handleEvent:function(e){
var obj=e.target.obj||null;
var _85=null;
if($class.instanceOf(obj,gara.jswt.TreeItem)){
_85=obj;
}
switch(e.type){
case "mousedown":
if(!this._hasFocus){
this.forceFocus();
}
if(_85!=null){
if(e.ctrlKey&&!e.shiftKey){
if(this._selection.contains(_85)){
this.deselect(_85);
}else{
this._select(_85,true);
}
}else{
if(!e.ctrlKey&&e.shiftKey){
this._selectShift(_85,false);
}else{
if(e.ctrlKey&&e.shiftKey){
this._selectShift(_85,true);
}else{
this._select(_85,false);
}
}
}
}
break;
case "dblclick":
break;
}
if(_85!=null){
_85.handleEvent(e);
}
e.stopPropagation();
},_handleKeyEvent:function(e){
if(this._activeItem==null){
return;
}
switch(e.keyCode){
case 38:
var _87;
if(this._activeItem==this._items[0]){
_87=false;
}else{
var _88;
var _89=this._activeItem.getParentItem();
if(_89==null){
_88=this._firstLevelItems;
}else{
_88=_89.getItems();
}
var _8a=_88.indexOf(this._activeItem);
if(_8a==0){
_87=_89;
}else{
var _8b=_88[_8a-1];
_87=getLastItem(_8b);
}
}
if(_87){
if(!e.ctrlKey&&!e.shiftKey){
this._select(_87,false);
}else{
if(e.ctrlKey&&e.shiftKey){
this._selectShift(_87,true);
}else{
if(e.shiftKey){
this._selectShift(_87,false);
}else{
if(e.ctrlKey){
this._activateItem(_87);
}
}
}
}
}
break;
case 40:
var _8c;
var _88;
if(this._activeItem==this._items[this._items.length-1]){
_8c=false;
}else{
var _89=this._activeItem.getParentItem();
if(_89==null){
_88=this._firstLevelItems;
}else{
_88=_89.getItems();
}
var _8a=_88.indexOf(this._activeItem);
if(this._activeItem.getItemCount()>0&&this._activeItem.getExpanded()){
_8c=this._activeItem.getItems()[0];
}else{
if(this._activeItem.getItemCount()>0&&!this._activeItem.getExpanded()){
_8c=this._items[this._items.indexOf(this._activeItem)+countItems(this._activeItem)+1];
}else{
_8c=this._items[this._items.indexOf(this._activeItem)+1];
}
}
}
if(_8c){
if(!e.ctrlKey&&!e.shiftKey){
this._select(_8c,false);
}else{
if(e.ctrlKey&&e.shiftKey){
this._selectShift(_8c,true);
}else{
if(e.shiftKey){
this._selectShift(_8c,false);
}else{
if(e.ctrlKey){
this._activateItem(_8c);
}
}
}
}
}
break;
case 37:
var _8d=this._activeItem;
this._activeItem.setExpanded(false);
this._activateItem(_8d);
this.update();
break;
case 39:
this._activeItem.setExpanded(true);
this.update();
break;
case 32:
if(this._selection.contains(this._activeItem)&&e.ctrlKey){
this.deselect(this._activeItem);
}else{
this._select(this._activeItem,true);
}
break;
case 36:
if(!e.ctrlKey&&!e.shiftKey){
this._select(this._items[0],false);
}else{
if(e.shiftKey){
this._selectShift(this._items[0],false);
}else{
if(e.ctrlKey){
this._activateItem(this._items[0]);
}
}
}
break;
case 35:
if(!e.ctrlKey&&!e.shiftKey){
this._select(this._items[this._items.length-1],false);
}else{
if(e.shiftKey){
this._selectShift(this._items[this._items.length-1],false);
}else{
if(e.ctrlKey){
this._activateItem(this._items[this._items.length-1]);
}
}
}
break;
}
function getLastItem(_8e){
if(_8e.getExpanded()&&_8e.getItemCount()>0){
return getLastItem(_8e.getItems()[_8e.getItemCount()-1]);
}else{
return _8e;
}
}
function countItems(_8f){
var _90=0;
var _91=_8f.getItems();
for(var i=0;i<_91.length;++i){
_90++;
if(_91[i].getItemCount()>0){
_90+=countItems(_91[i]);
}
}
return _90;
}
},indexOf:function(_93){
if(!$class.instanceOf(_93,gara.jswt.TreeItem)){
throw new TypeError("item not instance of gara.jswt.TreeItem");
}
if(!this._items.contains(_93)){
throw new gara.jswt.ItemNotExistsException("item ["+_93+"] does not exists in this list");
console.log("des item gibts hier ned: "+_93.getText());
return;
}
return this._items.indexOf(_93);
},_notifySelectionListener:function(){
this._selectionListeners.forEach(function(_94,_95,arr){
_94.widgetSelected(this);
},this);
},registerListener:function(_97,_98){
if(this.domref!=null){
gara.EventManager.getInstance().addListener(this.domref,_97,_98);
}
},removeSelectionListener:function(_99){
if(!$class.instanceOf(item,gara.jswt.SelectionListener)){
throw new TypeError("item is not type of gara.jswt.SelectionListener");
}
if(this._selectionListeners.contains(_99)){
this._selectionListeners.remove(_99);
}
},_select:function(_9a,_9b){
if(!$class.instanceOf(_9a,gara.jswt.TreeItem)){
throw new TypeError("item is not type of gara.jswt.TreeItem");
}
if(!_9b){
while(this._selection.length){
this._selection.pop().setChecked(false);
}
}
if(!this._selection.contains(_9a)&&_9a.getParent()==this){
this._selection.push(_9a);
_9a.setChecked(true);
this._shiftItem=_9a;
this._activateItem(_9a);
this._notifySelectionListener();
}
},selectAll:function(){
this._items.forEach(function(_9c,_9d,arr){
this._select(_9c,true);
},this);
this.update();
},_selectShift:function(_9f,_a0){
if(!$class.instanceOf(_9f,gara.jswt.TreeItem)){
throw new TypeError("item is not type of gara.jswt.TreeItem");
}
if(!_a0){
while(this._selection.length){
this._selection.pop().setChecked(false);
}
}
var _a1=this.indexOf(this._shiftItem);
var _a2=this.indexOf(_9f);
var _a3=_a1>_a2?_a2:_a1;
var to=_a1<_a2?_a2:_a1;
for(var i=_a3;i<=to;++i){
this._selection.push(this._items[i]);
this._items[i].setChecked(true);
}
this._activateItem(_9f);
this._notifySelectionListener();
},setLinesVisible:function(_a6){
this._showLines=_a6;
},toString:function(){
return "[gara.jswt.Tree]";
},update:function(){
if(this.domref==null){
this.domref=document.createElement("ul");
this.domref.obj=this;
this.domref.control=this;
base2.DOM.bind(this.domref);
var _a7={};
for(var _a8 in this._listener){
_a7[_a8]=this._listener[_a8].concat([]);
}
this.addListener("mousedown",this);
this.addListener("dblclick",this);
for(var _a8 in _a7){
_a7[_a8].forEach(function(_a9,_aa,arr){
this.registerListener(_a8,_a9);
},this);
}
this._parentNode.appendChild(this.domref);
}
this.removeClassName("jsWTTreeNoLines");
this.removeClassName("jsWTTreeLines");
if(this._showLines){
this.addClassName("jsWTTreeLines");
}else{
this.addClassName("jsWTTreeNoLines");
}
this.domref.className=this._className;
this._updateItems(this._firstLevelItems,this.domref);
},_updateItems:function(_ac,_ad){
var _ae=_ac.length;
_ac.forEach(function(_af,_b0,arr){
var _b2=(_b0+1)==_ae;
if(!_af.isCreated()){
_af.create(_b2);
_ad.appendChild(_af.domref);
}
if(_af.hasChanged()){
_af.update();
_af.releaseChange();
}
if(_af.getItemCount()>0){
var _b3=_af._getChildContainer();
this._updateItems(_af.getItems(),_b3);
}
if(_b2&&_af.getClassName().indexOf("bottom")==-1){
_af.addClassName("bottom");
if(_af.getItemCount()>0){
var cc=_af._getChildContainer();
cc.className="bottom";
}
}else{
if(!_b2&&_af.getClassName().indexOf("bottom")!=-1){
_af.removeClassName("bottom");
if(_af.getItemCount()>0){
var cc=_af._getChildContainer();
cc.className=null;
}
}
}
},this);
}});
$class("TreeItem",{$extends:Item,$constructor:function(_b5){
this.$base();
if(!($class.instanceOf(_b5,gara.jswt.Tree)||$class.instanceOf(_b5,gara.jswt.TreeItem))){
throw new TypeError("parentWidget is neither a gara.jswt.Tree or gara.jswt.TreeItem");
}
this._items=new Array();
this._expanded=true;
this._checked=false;
this._changed=false;
this._childContainer=null;
this._parent=_b5;
this._tree=null;
if($class.instanceOf(_b5,gara.jswt.Tree)){
this._tree=_b5;
}else{
if($class.instanceOf(_b5,gara.jswt.TreeItem)){
this._tree=_b5.getParent();
_b5._addItem(this);
}
}
this._tree._addItem(this);
this._img=null;
this._toggler=null;
this._span=null;
this._spanText=null;
},_addItem:function(_b6){
if(!$class.instanceOf(_b6,gara.jswt.TreeItem)){
throw new TypeError("item is not type of gara.jswt.TreeItem");
}
this._items.push(_b6);
},create:function(_b7){
if(_b7){
this.addClassName("bottom");
}
this.domref=document.createElement("li");
this.domref.className=this._className;
this.domref.obj=this;
this.domref.control=this._tree;
this._toggler=document.createElement("span");
this._toggler.obj=this;
this._toggler.control=this._tree;
this._span=document.createElement("span");
this._span.obj=this;
this._span.control=this._tree;
this._span.className="text";
this._spanText=document.createTextNode(this._text);
this._span.appendChild(this._spanText);
this._toggler.className="toggler";
this._toggler.className+=this._hasChilds()?(this._expanded?" togglerExpanded":" togglerCollapsed"):"";
this.domref.appendChild(this._toggler);
if(this._image!=null){
this._img=document.createElement("img");
this._img.obj=this;
this._img.src=this._image.src;
this._img.control=this._tree;
this.domref.appendChild(this._img);
}
this.domref.appendChild(this._span);
if(this._hasChilds()){
this._createChildContainer();
}
base2.DOM.bind(this.domref);
for(var _b8 in this._listeners){
this._listeners[_b8].forEach(function(_b9,_ba,arr){
this.registerListener(_b8,_b9);
},this);
}
},_createChildContainer:function(){
this._childContainer=document.createElement("ul");
if(this.getClassName().indexOf("bottom")!=-1){
this._childContainer.className="bottom";
}
if(this._expanded){
this._childContainer.style.display="block";
}else{
this._childContainer.style.display="none";
}
this.domref.appendChild(this._childContainer);
},_deselectItems:function(){
this._items.forEach(function(_bc,_bd,arr){
if(_bc._hasChilds()){
_bc._deselectItems();
}
this._tree.deselect(_bc);
},this);
},_getChildContainer:function(){
if(this._childContainer==null){
this._createChildContainer();
}
return this._childContainer;
},getChecked:function(){
return this._checked;
},getExpanded:function(){
return this._expanded;
},getItem:function(_bf){
if(_bf>=this._items.length){
throw new gara.OutOfBoundsException("Your item lives outside of this Tree");
}
return this._items[_bf];
},getItemCount:function(){
return this._items.length;
},getItems:function(){
return this._items;
},getParent:function(){
return this._tree;
},getParentItem:function(){
if(this._parent==this._tree){
return null;
}else{
return this._parent;
}
},_hasChilds:function(){
return this._items.length>0;
},handleEvent:function(e){
var obj=e.target.obj||null;
switch(e.type){
case "mousedown":
if($class.instanceOf(obj,gara.jswt.TreeItem)){
var _c2=obj;
if(e.target==this._toggler){
if(this._expanded){
this.setExpanded(false);
}else{
this.setExpanded(true);
}
this._tree.update();
}
}
break;
case "dblclick":
if($class.instanceOf(obj,gara.jswt.TreeItem)){
var _c2=obj;
if(e.target!=this._toggler){
if(this._expanded){
this.setExpanded(false);
}else{
this.setExpanded(true);
}
this._tree.update();
}
}
break;
}
},indexOf:function(_c3){
if(!$class.instanceOf(_c3,gara.jswt.TreeItem)){
throw new TypeError("item not instance of gara.jswt.TreeItem");
}
if(!this._items.contains(_c3)){
throw new gara.jswt.ItemNotExistsException("item ["+_c3+"] does not exists in this list");
console.log("des item gibts hier ned: "+_c3.getText());
return;
}
return this._items.indexOf(_c3);
},registerListener:function(_c4,_c5){
if(this._img!=null){
gara.EventManager.getInstance().addListener(this._img,_c4,_c5);
}
if(this._span!=null){
gara.EventManager.getInstance().addListener(this._span,_c4,_c5);
}
},removeAll:function(){
this._items=[];
},setActive:function(_c6){
this._active=_c6;
if(_c6){
this._span.className+=" active";
}else{
this._span.className=this._span.className.replace(/ *active/,"");
}
this._changed=true;
},setChecked:function(_c7){
if(_c7){
this._span.className="text selected";
}else{
this._span.className="text";
}
this._checked=_c7;
},setExpanded:function(_c8){
this._expanded=_c8;
if(!_c8){
this._deselectItems();
}
this._changed=true;
},toString:function(){
return "[gara.jswt.TreeItem]";
},update:function(){
if(this._hasChilds()){
this._toggler.className=strReplace(this._toggler.className," togglerCollapsed","");
this._toggler.className=strReplace(this._toggler.className," togglerExpanded","");
if(this._expanded){
this._toggler.className+=" togglerExpanded";
}else{
this._toggler.className+=" togglerCollapsed";
}
}
if(this._image!=null&&this._img==null){
this._img=document.createElement("img");
this._img.obj=this;
this._img.control=this._tree;
this._img.alt=this._text;
this._img.src=this._image.src;
this.domref.insertBefore(this._img,this._span);
}else{
if(this._image!=null){
this._img.src=this._image.src;
this._img.alt=this._text;
}else{
if(this._img!=null&&this._image==null){
this.domref.removeChild(this._img);
this._img=null;
}
}
}
if(this._hasChilds()&&this._childContainer==null){
this._createChildContainer();
}
if(this._childContainer!=null){
if(this._expanded){
this._childContainer.style.display="block";
}else{
this._childContainer.style.display="none";
}
}else{
if(!this._hasChilds()&&this._childContainer!=null){
this.domref.removeChild(this._childContainer);
this._childContainer=null;
}
}
this._spanText.nodeValue=this._text;
this.domref.className=this._className;
}});
$class("TabFolder",{$extends:Control,$constructor:function(_c9,_ca){
this.$base();
this._style=_ca||gara.jswt.TOP;
this._items=[];
this._activeItem=null;
this._parentNode=_c9;
this._selectionListener=[];
this._selection=[];
this._tabbar=null;
this._clientArea=null;
this._className=this._baseClass="jsWTTabFolder";
},_addItem:function(_cb){
if(!$class.instanceOf(_cb,gara.jswt.TabItem)){
throw new TypeError("item is not type of gara.jswt.TabItem");
}
this._items.push(_cb);
},addSelectionListener:function(_cc){
if(!$class.instanceOf(_cc,gara.jswt.SelectionListener)){
throw new TypeError("listener is not instance of gara.jswt.SelectionListener");
}
this._selectionListener.push(_cc);
},_activateItem:function(_cd){
if(!$class.instanceOf(_cd,gara.jswt.TabItem)){
throw new TypeError("item is not type of gara.jswt.TabItem");
}
if(this._activeItem!=null){
this._activeItem.setActive(false);
}
this._activeItem=_cd;
_cd._setActive(true);
this._clientArea.innerHTML=_cd.getContent();
this.update();
this._selection=[];
this._selection.push(_cd);
this._notifySelectionListener();
},getClientArea:function(){
return this._clientArea;
},getItem:function(_ce){
if(_ce>=this._items.length){
throw new gara.OutOfBoundsException("Your item lives outside of this tabfolder");
}
return this._items[_ce];
},getItemCount:function(){
return this._items.length;
},getItems:function(){
return this._items;
},getSelection:function(){
return this._selection;
},getSelectionIndex:function(){
if(this._selection.length){
return this._items.indexOf(this._selection[0]);
}else{
return -1;
}
},handleEvent:function(e){
var obj=e.target.obj||null;
switch(e.type){
case "mousedown":
if(!this._hasFocus){
this.forceFocus();
}
if($class.instanceOf(obj,gara.jswt.TabItem)){
var _d1=obj;
this._activateItem(_d1);
}
break;
}
if(e.target!=this.domref){
e.stopPropagation();
}
},indexOf:function(_d2){
if(!$class.instanceOf(_d2,gara.jswt.TabItem)){
throw new TypeError("item not instance of gara.jswt.TabItem");
}
if(!this._items.contains(_d2)){
throw new gara.jswt.ItemNotExistsException("item ["+_d2+"] does not exists in this list");
}
return this._items.indexOf(_d2);
},_notifySelectionListener:function(){
for(var i=0,len=this._selectionListener.length;i<len;++i){
this._selectionListener[i].widgetSelected(this);
}
},registerListener:function(_d5,_d6){
if(this.domref!=null){
gara.EventManager.getInstance().addListener(this.domref,_d5,_d6);
}
},removeSelectionListener:function(_d7){
if(!$class.instanceOf(_d7,gara.jswt.SelectionListener)){
throw new TypeError("listener is not instance of gara.jswt.SelectionListener");
}
if(this._selectionListener.contains(_d7)){
this._selectionListener.remove(_d7);
}
},setSelection:function(arg){
if(typeof (arg)=="number"){
if(index>=this._items.length){
throw new gara.OutOfBoundsException("Your item lives outside of this tabfolder");
}
this._activateItem(this._items[arg]);
}else{
if($class.instanceOf(arg,Array)){
if(arg.length){
this._activateItem(arg[0]);
}
}
}
},toString:function(){
return "[gara.jswt.TabFolder]";
},update:function(){
if(this.domref==null){
this.domref=document.createElement("div");
this.domref.obj=this;
this.domref.control=this;
base2.DOM.bind(this.domref);
this._tabbar=document.createElement("ul");
this._tabbar.obj=this;
this._tabbar.control=this;
this._clientArea=document.createElement("div");
this._clientArea.className="jsWTTabClientArea";
if(this._style==gara.jswt.TOP){
this.domref.appendChild(this._tabbar);
this.domref.appendChild(this._clientArea);
this._tabbar.className="jsWTTabbar jsWTTabbarTop";
}else{
this.domref.appendChild(this._clientArea);
this.domref.appendChild(this._tabbar);
this._tabbar.className="jsWTTabbar jsWTTabbarBottom";
}
var _d9={};
for(var _da in this._listener){
_d9[_da]=this._listener[_da].concat([]);
}
this.addListener("mousedown",this);
for(var _da in _d9){
_d9[_da].forEach(function(_db,_dc,arr){
this.registerListener(_da,_db);
},this);
}
this._parentNode.appendChild(this.domref);
}
this.domref.className=this._className;
this._items.forEach(function(_de,_df,arr){
if(!_de.isCreated()){
node=_de._create();
this._tabbar.appendChild(node);
}
if(_de.hasChanged()){
_de.update();
_de.releaseChange();
}
},this);
}});
$class("TabItem",{$extends:Item,$constructor:function(_e1){
this.$base();
if(!$class.instanceOf(_e1,gara.jswt.TabFolder)){
throw new TypeError("parentWidget is neither a gara.jswt.TabFolder");
}
this._parent=_e1;
this._active=false;
this._content=null;
this._control=null;
this._toolTipText=null;
this._span=null;
this._img=null;
this._parent._addItem(this);
},_create:function(){
this.domref=document.createElement("li");
this.domref.className=this._className;
this.domref.obj=this;
this.domref.control=this._parent;
this.domref.title=this._toolTipText;
if(this.image!=null){
this._img=document.createElement("img");
this._img.obj=this;
this._img.control=this._parent;
this._img.src=this.image.src;
this._img.alt=this._text;
this.domref.appendChild(this._img);
}
this._spanText=document.createTextNode(this._text);
this._span=document.createElement("span");
this._span.obj=this;
this._span.control=this._parent;
this._span.appendChild(this._spanText);
this.domref.appendChild(this._span);
base2.DOM.bind(this.domref);
for(var _e2 in this._listener){
this._listener[_e2].forEach(function(_e3,_e4,arr){
this.registerListener(_e2,_e3);
},this);
}
this._changed=false;
return this.domref;
},getContent:function(){
return this._content;
},getControl:function(){
return this._control;
},getToolTipText:function(){
return this._toolTipText;
},registerListener:function(){
if(this.domref!=null){
gara.EventManager.getInstance().addListener(this.domref,eventType,listener);
}
},_setActive:function(_e6){
this._active=_e6;
if(_e6){
this._className+=" active";
}else{
this._className=this._className.replace(/ *active/,"");
}
this._changed=true;
},setContent:function(_e7){
this._content=_e7;
this._changed=true;
},setControl:function(_e8){
if(!$class.instanceOf(_e8,gara.jswt.Control)){
throw new TypeError("control is not instance of gara.jswt.Control");
}
this._control=_e8;
this.setContent(_e8.domref);
},setToolTipText:function(_e9){
this._toolTipText=_e9;
this._changed=true;
},update:function(){
if(this._image!=null&&this._img==null){
this._img=document.createElement("img");
this._img.obj=this;
this._img.control=this._parent;
this._img.alt=this._text;
this._img.src=this._image.src;
this.domref.insertBefore(this._img,this._span);
for(var _ea in this._listener){
this._listener[_ea].forEach(function(_eb,_ec,arr){
this.registerListener(this._img,_ea,_eb);
},this);
}
}else{
if(this._image!=null){
this._img.src=this._image.src;
this._img.alt=this._text;
}else{
if(this._img!=null&&this._image==null){
this.domref.removeChild(this._img);
this._img=null;
for(var _ea in this._listener){
this._listener[_ea].forEach(function(_ee,_ef,arr){
gara.EventManager.getInstance().removeListener({domNode:this._img,type:_ea,listener:_ee});
},this);
}
}
}
}
this._spanText.nodeValue=this._text;
this.domref.className=this._className;
}});
$class("ControlManager",{$implements:FocusListener,_instance:null,$constructor:function(){
this._activeControl=null;
this._controls=[];
gara.EventManager.getInstance().addListener(document,"keydown",this);
gara.EventManager.getInstance().addListener(document,"mousedown",this);
},getInstance:$static(function(){
if(this._instance==null){
this._instance=new gara.jswt.ControlManager();
}
return this._instance;
}),addControl:function(_f1){
if(!this._controls.contains(_f1)){
this._controls.push(_f1);
}
},focusGained:function(_f2){
if(!$class.instanceOf(_f2,gara.jswt.Control)){
throw new TypeError("control is not a gara.jswt.Control");
}
this._activeControl=_f2;
},focusLost:function(_f3){
if(!$class.instanceOf(_f3,gara.jswt.Control)){
throw new TypeError("control is not a gara.jswt.Control");
}
if(this._activeControl==_f3){
this._activeControl=null;
}
},handleEvent:function(e){
if(e.type=="keydown"){
if(this._activeControl!=null&&this._activeControl._handleKeyEvent){
this._activeControl._handleKeyEvent(e);
}
}
if(e.type=="mousedown"){
if(this._activeControl!=null&&(e.target.control?e.target.control!=this._activeControl:true)){
this._activeControl.looseFocus();
this._activeControl=null;
}
}
},removeControl:function(_f5){
if(!$class.instanceOf(_f5,gara.jswt.Control)){
throw new TypeError("control is not a gara.jswt.Control");
}
if(this._controls.contains(_f5)){
if(this._activeControl==_f5){
this._activeControl=null;
}
this._controls.remove(_f5);
}
},toString:function(){
return "[gara.jswt.ControlManager]";
}});
eval(_26.exports);
gara.jswt.namespace=_26.namespace;
gara.jswt.toString=function(){
return "[gara.jswt]";
};
};
delete Control;
delete ControlManager;
delete FocusListener;
delete Item;
delete ItemNotExistsException;
delete List;
delete ListItem;
delete Tree;
delete TreeItem;
delete TabFolder;
delete TabItem;
delete SelectionListener;
delete Widget;

